<?php
$h1 = "Информация обо мне";
$title = "Главная страница - страница обо мне";
$year = date('Y');

include "site_2.html";