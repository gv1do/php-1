<?php

//TODO соберите страницу about полностью вместе с меню.

function renderTemplate($page, $menu = '', $content = '') {
    ob_start();
    include  "templates/" . $page . ".php";
    return ob_get_clean();
}

$menu = renderTemplate('menu');
$content = renderTemplate('about', $menu);


echo renderTemplate('main', $menu);
echo renderTemplate('about', $menu, $content);