<a href="/">Главная</a>
<a href="/">О нас</a><br>